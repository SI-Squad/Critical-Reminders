# Zoom-a-loom
Definitely not a gerrymandering game (Nope)

## Resources
Google Extension Docs: https://developer.chrome.com/docs/extensions/mv3/
Google Calendar Docs: https://developers.google.com/calendar/overview
